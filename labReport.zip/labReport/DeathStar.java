package lab1;

public class DeathStar extends SpaceShip
{

}
