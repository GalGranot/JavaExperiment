package lab1;

public class VehicleNotFoundException extends RuntimeException
{
	public VehicleNotFoundException(String str)
	{
		super(str);
	}
}
