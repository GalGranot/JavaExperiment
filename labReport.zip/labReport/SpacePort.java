package lab1;

public class SpacePort extends ParkingLot
{
	public SpacePort(int size, float in_fee)
	{
		super(size, in_fee);
	}
}
