package lab1;

public class StorageError extends RuntimeException
{
	public StorageError(String str)
	{
		super(str);
	}
}
